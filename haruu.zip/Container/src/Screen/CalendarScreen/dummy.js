const DATA2 = [
  {
    id: "1",
    image: require("../../../../assets/images/dochi.jpg"),
    message: "매일매일 노력하는 모습 멋지다~",
  },
  {
    id: "2",
    image: require("../../../../assets/images/sample.jpg"),
    message: "꾸준한 연습이 완벽을 만든다!",
  },
  {
    id: "3",
    image: require("../../../../assets/images/sample.jpg"),
    message: "Hello~",
  },
];
export default DATA2;
