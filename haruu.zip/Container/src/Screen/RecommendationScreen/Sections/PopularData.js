const POPDATA = [
  {
    id: "1",
    title: "미뤄왔던 코딩 공부,\n오늘부터 해보는게 어때요?",
    description: "복사 붙여넣기는 이제 그만!\n기초부터 차근차근 시작해보세요",
    image: require("../../../../../assets/images/2.png"),
  },
  {
    id: "2",
    title: "친구와 만나지 않고도 함께 공부할 수 있어요.",
    description: "약속된 시간에 함께 공부하는 시간을 가져보세요",
    image: require("../../../../../assets/images/3.png"),
  },
  {
    id: "3",
    title: "재태크에 관심을 가져야하는 건 어른들뿐만이 아니에요.",
    description: "푼돈으로 목돈 만드는 소비습관, 저희와 함께 만들어가요.",
    image: require("../../../../../assets/images/4.png"),
  },
  {
    id: "4",
    title: "여유로운 오후 햇살과 함께 스트레칭을",
    description: "최고의 건강 유지 비결은 매일매일 꾸준한 스트레칭이에요",
    image: require("../../../../../assets/images/1.png"),
  },
];
export default POPDATA;
