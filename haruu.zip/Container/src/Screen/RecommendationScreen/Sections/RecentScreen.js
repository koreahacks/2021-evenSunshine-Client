import React, { useEffect } from "react";
import {
  Alert,
  StyleSheet,
  Text,
  TextInput,
  View,
  Animated,
  Image,
  TouchableOpacity,
  Platform,
  Dimensions,
} from "react-native";

function RecentScreen() {
  return (
    <View>
      <Text>Hello</Text>
    </View>
  );
}

export default RecentScreen;
