import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import { ScrollView } from "react-native-gesture-handler";

function CommunityScreen() {
  const [Data, setData] = useState();

  const loadData = async () => {
    const token = await AsyncStorage.getItem("token");
    var axios = require("axios");
    var config = {
      method: "get",
      url: "https://evensunshine.herokuapp.com/mypage/getComment",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };
    axios(config)
      .then(function (response) {
        setData(response.data.comments);
        console.log(response.data.comments);
      })
      .catch(function (error) {
        console.log(error);
      });
  };
  useEffect(() => {
    loadData();
  }, []);

  const Item = ({ item }) => {
    if (item.commentImage === "noImage") {
      return (
        <View style={{ marginHorizontal: 20 }}>
          <View style={{ flexDirection: "row", margin: 5 }}>
            <Image
              source={{ uri: `${item.profileImage}` }}
              style={{ width: 20, height: 20 }}
            />
            <Text style={{ marginLeft: 5 }}>{item.displayName}님</Text>
          </View>
          <Text style={{ marginVertical: 10, fontSize: 18, fontWeight: "700" }}>
            {item.title}
          </Text>
          <Text>{item.comment}</Text>
          <View style={{ flexDirection: "row", marginLeft: 150 }}>
            <Text style={{ marginVertical: 10 }}>
              하트를 눌러 응원해주세요!
            </Text>
            <Image
              source={require("../../../../assets/images/heart.png")}
              style={{ width: 40, height: 40 }}
            />
          </View>
          <View
            style={{ width: "100%", height: 0.5, backgroundColor: "gray" }}
          ></View>
        </View>
      );
    } else {
      return (
        <View style={{ margin: 20 }}>
          <View style={{ flexDirection: "row", margin: 5 }}>
            <Image
              source={{ uri: `${item.profileImage}` }}
              style={{ width: 20, height: 20 }}
            />
            <Text style={{ marginLeft: 5 }}>{item.displayName}님</Text>
          </View>

          <View style={{ flex: 1, alignItems: "center" }}>
            <Image
              source={{ uri: `${item.commentImage}` }}
              style={{ width: 340, height: 340 }}
            />
          </View>

          <Text style={{ marginVertical: 10, fontSize: 18, fontWeight: "700" }}>
            {item.title}
          </Text>
          <Text>{item.comment}</Text>
          <View style={{ flexDirection: "row", marginLeft: 150 }}>
            <Text style={{ marginVertical: 10 }}>
              하트를 눌러 응원해주세요!
            </Text>
            <Image
              source={require("../../../../assets/images/heart.png")}
              style={{ width: 40, height: 40 }}
            />
          </View>
          <View
            style={{ width: "100%", height: 0.5, backgroundColor: "gray" }}
          ></View>
        </View>
      );
    }
  };

  return (
    <View style={{ backgroundColor: "white" }}>
      <View style={{ flex: 1, alignItems: "center", backgroundColor: "white" }}>
        <Image
          source={require("../../../../assets/images/search.png")}
          style={{
            width: 300,
            resizeMode: "stretch",
            height: 50,
            marginTop: 30,
          }}
        />
      </View>

      <View
        style={{
          width: "100%",
          height: 5,
          backgroundColor: "#D8D8D8",
          marginTop: 80,
        }}
      ></View>

      <ScrollView>
        <View style={{ paddingBottom: 100 }}>
          <Text style={{ fontSize: 20, fontWeight: "bold", margin: 20 }}>
            목표 후기
          </Text>
          <FlatList
            data={Data}
            renderItem={Item}
            keyExtractor={(item) => item._id}
          />
        </View>
      </ScrollView>
    </View>
  );
}

export default CommunityScreen;
