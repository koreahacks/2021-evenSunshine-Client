import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";

function MyPageScreen() {
  return (
    <View style={{ flex: 1, alignItems: "center" }}>
      <Image source={require("../../../../assets/images/11.png")} />
    </View>
  );
}

export default MyPageScreen;
